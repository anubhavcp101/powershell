<#
.SYNOPSIS
    Windows Server Disk Space Management & Analysis Framework - Main Workspace Entrypoint.
.DESCRIPTION
    Strictly read-only discovery and auditing framework for Windows Server 2016 - 2025.
    Analyzes disk usage, identifies oversized and historical files, evaluates system
    components (DISM WinSxS, VSS, IIS, WER, Pagefile), classifies findings into
    risk-aware categories, and generates Executive HTML and detailed CSV reports.
.PARAMETER Drives
    Target drive letter(s) to scan (e.g. 'C:'). Default is 'C:'.
.PARAMETER ScanPaths
    Optional custom array of directory paths to scan.
.PARAMETER ConfigPath
    Path to custom configuration file.
.PARAMETER Mode
    Operational mode: Discovery, Audit, Detailed, Report, or Full (Default).
.PARAMETER OutputPath
    Directory where HTML and CSV reports will be saved.
.PARAMETER SkipDism
    Skip running DISM Component Store analysis (useful for rapid audits).
.PARAMETER SkipShadowCopy
    Skip querying VSS Volume Shadow Storage.
.EXAMPLE
    .\discoverySpace.ps1 -Mode Full
.EXAMPLE
    .\discoverySpace.ps1 -Drives 'C:' -SkipDism
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string[]]$Drives = @('C:'),

    [Parameter(Mandatory = $false)]
    [string[]]$ScanPaths = $null,

    [Parameter(Mandatory = $false)]
    [string]$ConfigPath = $null,

    [Parameter(Mandatory = $false)]
    [ValidateSet('Discovery', 'Audit', 'Detailed', 'Report', 'Full')]
    [string]$Mode = 'Full',

    [Parameter(Mandatory = $false)]
    [string]$OutputPath = $null,

    [Parameter(Mandatory = $false)]
    [switch]$SkipDism,

    [Parameter(Mandatory = $false)]
    [switch]$SkipShadowCopy
)

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$orchestratorPath = Join-Path -Path $scriptDir -ChildPath "DiskSpaceAnalyzer\Start-DiskSpaceAnalysis.ps1"

if (-not (Test-Path -LiteralPath $orchestratorPath)) {
    Write-Error "Could not locate framework orchestrator at: $orchestratorPath"
    return
}

# Forward all arguments directly to Start-DiskSpaceAnalysis.ps1
& $orchestratorPath @PSBoundParameters
