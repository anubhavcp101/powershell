# Windows Server Disk Space Management & Analysis Framework

A production-grade, modular, strictly **read-only** PowerShell framework engineered for enterprise Windows Server environments (Windows Server 2016, 2019, 2022, and 2025).

---

## 1. Architectural Overview

```
DiskSpaceAnalyzer/
│
├── Config/
│   └── Config.psd1               # Central policy configuration (paths, thresholds, extensions)
│
├── Modules/
│   ├── Logging.psm1              # Multi-level structured console & file logging
│   ├── DiskDiscovery.psm1        # Volume capacity, free space %, and CIM/WMI metrics
│   ├── FileDiscovery.psm1        # High-performance non-recursive stack traversal
│   ├── DirectoryAnalysis.psm1    # Directory sizing, high file-count alerts, extension analysis
│   ├── FileClassification.psm1   # Category A (Candidates), B (Manual), C (Protected) engine
│   ├── WindowsAnalysis.psm1      # DISM Component Store, VSS, IIS, WER, and Pagefile analyzers
│   └── ReportGenerator.psm1      # Executive HTML report and 9 targeted CSV exports
│
├── Reports/                      # Output directory for HTML and CSV run artifacts
├── Logs/                         # Timestamped audit and execution logs
├── Start-DiskSpaceAnalysis.ps1   # Framework orchestrator
└── README.md                     # Technical architecture, safety guidelines, and runbook
```

---

## 2. Core Operational Principles & Safety Guarantees

> [!CAUTION]
> **STRICT READ-ONLY GUARANTEE**: This framework will **NEVER**:
> - Delete, truncate, move, or rename any file or directory.
> - Compress or alter file content or NTFS attributes.
> - Change access control lists (ACLs), ownership, or file permissions.
> - Modify registry keys, stop or restart Windows services, or clear Event Logs.
> - Execute destructive DISM cleanups (`/ResetBase`, `/StartComponentCleanup`) or purge VSS shadow copies.

All discovery mechanisms inspect metadata only. File metrics identified as "Potential Cleanup Opportunities" represent theoretical candidates based on retention policies and require administrator validation prior to operational action.

---

## 3. Platform & PowerShell Compatibility

| Operating System | Compatibility | PowerShell Version | Engine Notes |
| :--- | :--- | :--- | :--- |
| **Windows Server 2025** | Full | PS 5.1 & PS 7.x | CIM/WMI, DISM v10.0, Modern VSS integration |
| **Windows Server 2022** | Full | PS 5.1 & PS 7.x | CIM/WMI, DISM v10.0, Native Stack Scanner |
| **Windows Server 2019** | Full | PS 5.1 & PS 7.x | CIM/WMI, DISM v10.0, Long-path aware |
| **Windows Server 2016** | Full | Windows PowerShell 5.1 | Backward compatible CIM/WMI fallback |

---

## 4. Classification Engine Hierarchy

Discovered items are evaluated using a multi-criteria engine (Path, Extension, Age, Size, and Known Dependencies):

### Category A – Potential Cleanup Candidates
Files that match predefined retention thresholds and safe cleanup signatures:
- **Old Inactive Logs**: `.etl`, `.evtx`, `.log` older than 180 days.
- **Historical Diagnostic Traces**: `.wer`, `.trace`, `.blg` older than 180 days.
- **Old Crash Dumps**: `.dmp`, `.mdmp`, `.hdmp` in `C:\Windows\Minidump` or `LiveKernelReports` older than 90 days.
- **Expired Temporary Files**: `.tmp`, `.~tmp` in Temp directories older than 14 days.
- **Rotated IIS Access Logs**: W3C logs in `C:\inetpub\logs\LogFiles` older than 90 days.

### Category B – Manual Investigation Required
Files that consume significant space but require administrative or application-owner review:
- Installer and patch packages (`.msi`, `.msp`, `.cab`, `.wim`).
- Backup archives (`.bak`, `.zip`, `.7z`, `.rar`).
- Files located within `C:\ProgramData` or user profile directories.
- Unclassified large files exceeding the size threshold (default 100 MB).

### Category C – Protected (Excluded from Cleanup)
Critical system components flagged strictly as read-only references:
- Windows Component Store (`C:\Windows\WinSxS`).
- Windows Installer Cache (`C:\Windows\Installer`).
- Registry Hives (`C:\Windows\System32\config`).
- Active Windows Event Logs (`C:\Windows\System32\winevt\Logs`).
- Paging and hibernation files (`pagefile.sys`, `swapfile.sys`, `hiberfil.sys`).
- Active Database engines (SQL Server `.mdf`/`.ldf`, Hyper-V `.vhdx`).
- System Volume Information, Recovery, and Boot partitions.

---

## 5. Execution Modes

The framework supports 4 operational modes via the `-Mode` parameter:

| Mode | Operations Executed | Output Produced |
| :--- | :--- | :--- |
| `Discovery` | Volume metrics, directory and file inventory | Console output & structured log |
| `Audit` | Discovery + Category A/B/C classification rules | Classification summaries & log |
| `Detailed` | Discovery + Audit + DISM, VSS, IIS, & WER analyzers | In-depth subsystem diagnostics |
| `Report` | Discovery + Classification + Windows Analyzers + Reports | Executive HTML + 9 CSV files |
| `Full` *(Default)* | End-to-end execution of all phases | Complete HTML + CSV suite + Full logs |

---

## 6. Usage & CLI Examples

### Run Full Scan on C: (Default)
```powershell
# From framework root
.\Start-DiskSpaceAnalysis.ps1 -Mode Full

# Or via workspace entrypoint
.\discoverySpace.ps1 -Mode Full
```

### Rapid Scan Skipping Long-Running DISM Component Store Analysis
```powershell
.\discoverySpace.ps1 -SkipDism -SkipShadowCopy
```

### Scan Specific Custom Locations
```powershell
.\discoverySpace.ps1 -ScanPaths @('C:\inetpub\logs\LogFiles', 'C:\Windows\Temp')
```

### Custom Output Directory
```powershell
.\discoverySpace.ps1 -OutputPath 'D:\ServerAudits\Reports'
```

---

## 7. Reports Generated

Upon completion, a timestamped subfolder under `Reports/` is created containing:

1. **`Executive_DiskSpace_Report.html`**: Interactive executive dashboard displaying drive capacity cards, cleanup opportunity estimates, top 30 largest files, top 30 directories, extension breakdowns, DISM/VSS status, and engineering recommendations.
2. **`CategoryA_Candidates.csv`**: Granular list of potential cleanup candidates with age and file details.
3. **`CategoryB_ManualInvestigation.csv`**: Installer files, archives, and unclassified items.
4. **`CategoryC_Protected.csv`**: Protected system components, active logs, and database files.
5. **`LargeFiles.csv`**: All files exceeding the size threshold (e.g. >= 100 MB).
6. **`OldFiles.csv`**: Files exceeding retention periods regardless of size.
7. **`DirectorySummary.csv`**: Complete directory inventory with sizes, file counts, and high file-count flags.
8. **`ExtensionSummary.csv`**: Aggregated file counts and storage consumption by file extension.
9. **`ScanErrors.csv`**: Inaccessible paths, locked files, and permission denials encountered during the scan.
10. **`AllDiscoveredFiles.csv`**: Full inventory of all enumerated files.
