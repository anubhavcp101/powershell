# =========================================================================
# Module: Logging.psm1
# Windows Server Disk Space Management & Analysis Framework
# Thread-safe, multi-level structured logger supporting PS 5.1+
# =========================================================================

Set-StrictMode -Version 2.0

$script:LogFilePath = $null
$script:ScanErrors  = [System.Collections.Generic.List[PSObject]]::new()

function Initialize-DiskLogger {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [string]$LogsDirectory,

        [Parameter(Mandatory = $false)]
        [string]$Prefix = "DiskSpaceAnalysis"
    )

    if ([string]::IsNullOrWhiteSpace($LogsDirectory)) {
        $LogsDirectory = Join-Path -Path $PSScriptRoot -ChildPath "..\Logs"
    }

    if (-not (Test-Path -Path $LogsDirectory)) {
        [void](New-Item -ItemType Directory -Path $LogsDirectory -Force)
    }

    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $script:LogFilePath = Join-Path -Path $LogsDirectory -ChildPath "$($Prefix)_$timestamp.log"
    $script:ScanErrors.Clear()

    Write-DiskLog -Message "Logging initialized. Log file: $script:LogFilePath" -Level "INFO"
    return $script:LogFilePath
}

function Write-DiskLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message,

        [Parameter(Mandatory = $false)]
        [ValidateSet("INFO", "WARN", "ERROR", "DEBUG", "SUCCESS")]
        [string]$Level = "INFO",

        [Parameter(Mandatory = $false)]
        [string]$Path = $null
    )

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
    $formattedLog = "[$timestamp] [$Level] $Message"
    if ($Path) {
        $formattedLog += " | Path: $Path"
    }

    # Console display with color
    switch ($Level) {
        "INFO"    { Write-Host $formattedLog -ForegroundColor Gray }
        "WARN"    { Write-Host $formattedLog -ForegroundColor Yellow }
        "ERROR"   { Write-Host $formattedLog -ForegroundColor Red }
        "DEBUG"   { Write-Verbose $formattedLog }
        "SUCCESS" { Write-Host $formattedLog -ForegroundColor Green }
    }

    # File append with locking retry
    if ($script:LogFilePath) {
        try {
            [System.IO.File]::AppendAllText($script:LogFilePath, $formattedLog + [System.Environment]::NewLine, [System.Text.Encoding]::UTF8)
        }
        catch {
            # Fallback to Write-Warning if file write is temporarily contended
            Write-Warning "Could not append to log file: $_"
        }
    }
}

function Register-DiskScanError {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$ErrorType,

        [Parameter(Mandatory = $true)]
        [string]$ErrorMessage
    )

    $errorObj = [PSCustomObject]@{
        Timestamp    = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
        Path         = $Path
        ErrorType    = $ErrorType
        ErrorMessage = $ErrorMessage
    }

    $script:ScanErrors.Add($errorObj)
    Write-DiskLog -Message "Scan Error [$ErrorType]: $ErrorMessage" -Level "DEBUG" -Path $Path
}

function Get-DiskScanErrors {
    [CmdletBinding()]
    param()
    return $script:ScanErrors.ToArray()
}

Export-ModuleMember -Function Initialize-DiskLogger, Write-DiskLog, Register-DiskScanError, Get-DiskScanErrors
