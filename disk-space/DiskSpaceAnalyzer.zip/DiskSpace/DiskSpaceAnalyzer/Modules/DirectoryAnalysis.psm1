# =========================================================================
# Module: DirectoryAnalysis.psm1
# Windows Server Disk Space Management & Analysis Framework
# Aggregates directory sizes, file counts, and extension distribution
# =========================================================================

Set-StrictMode -Version 2.0

function Get-DirectorySizeSummary {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [array]$FileList,

        [Parameter(Mandatory = $false)]
        [int]$TopCount = 30,

        [Parameter(Mandatory = $false)]
        [int]$HighFileCountThreshold = 5000
    )

    $dirMap = @{}

    foreach ($file in $FileList) {
        $dir = $file.DirectoryName
        if (-not $dir) { $dir = "Unknown" }

        if (-not $dirMap.ContainsKey($dir)) {
            $dirMap[$dir] = [PSCustomObject]@{
                DirectoryPath = $dir
                TotalBytes    = [int64]0
                FileCount     = [int64]0
                OldestFileDate= $file.LastWriteTime
                NewestFileDate= $file.LastWriteTime
            }
        }

        $entry = $dirMap[$dir]
        $entry.TotalBytes += [int64]$file.Length
        $entry.FileCount += 1

        if ($file.LastWriteTime -lt $entry.OldestFileDate) {
            $entry.OldestFileDate = $file.LastWriteTime
        }
        if ($file.LastWriteTime -gt $entry.NewestFileDate) {
            $entry.NewestFileDate = $file.LastWriteTime
        }
    }

    $allDirs = [System.Collections.Generic.List[PSObject]]::new()
    foreach ($k in $dirMap.Keys) {
        $item = $dirMap[$k]
        $bytes = $item.TotalBytes
        $allDirs.Add([PSCustomObject]@{
            DirectoryPath    = $item.DirectoryPath
            TotalBytes       = $bytes
            TotalMB          = [math]::Round($bytes / 1MB, 2)
            TotalGB          = [math]::Round($bytes / 1GB, 3)
            FileCount        = $item.FileCount
            OldestFileDate   = $item.OldestFileDate
            NewestFileDate   = $item.NewestFileDate
            IsHighFileCount  = ($item.FileCount -ge $HighFileCountThreshold)
        })
    }

    # Top directories by size
    $topLargestDirs = $allDirs | Sort-Object -Property TotalBytes -Descending | Select-Object -First $TopCount
    # Directories with high file count
    $highCountDirs = $allDirs | Where-Object { $_.IsHighFileCount -eq $true } | Sort-Object -Property FileCount -Descending

    return [PSCustomObject]@{
        AllDirectories        = $allDirs.ToArray()
        TopLargestDirectories = @($topLargestDirs)
        HighFileCountDirs     = @($highCountDirs)
    }
}

function Get-ExtensionDistribution {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [array]$FileList
    )

    $extMap = @{}

    foreach ($file in $FileList) {
        $ext = $file.Extension
        if ([string]::IsNullOrWhiteSpace($ext)) {
            $ext = "(No Extension)"
        }

        if (-not $extMap.ContainsKey($ext)) {
            $extMap[$ext] = [PSCustomObject]@{
                Extension  = $ext
                FileCount  = [int64]0
                TotalBytes = [int64]0
            }
        }

        $extMap[$ext].FileCount += 1
        $extMap[$ext].TotalBytes += [int64]$file.Length
    }

    $results = [System.Collections.Generic.List[PSObject]]::new()
    foreach ($key in $extMap.Keys) {
        $e = $extMap[$key]
        $bytes = $e.TotalBytes
        $results.Add([PSCustomObject]@{
            Extension   = $e.Extension
            FileCount   = $e.FileCount
            TotalBytes  = $bytes
            TotalMB     = [math]::Round($bytes / 1MB, 2)
            TotalGB     = [math]::Round($bytes / 1GB, 3)
        })
    }

    return ($results | Sort-Object -Property TotalBytes -Descending)
}

Export-ModuleMember -Function Get-DirectorySizeSummary, Get-ExtensionDistribution
