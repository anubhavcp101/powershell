# =========================================================================
# Module: DiskDiscovery.psm1
# Windows Server Disk Space Management & Analysis Framework
# Queries volume metrics across Windows Server 2016 - 2025
# =========================================================================

Set-StrictMode -Version 2.0

function Get-DiskSpaceOverview {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [string[]]$Drives = @('C:')
    )

    $results = [System.Collections.Generic.List[PSObject]]::new()

    foreach ($drive in $Drives) {
        $cleanDrive = $drive.TrimEnd('\').ToUpper()
        if (-not $cleanDrive.EndsWith(':')) {
            $cleanDrive += ":"
        }

        $diskInfo = $null
        try {
            # Attempt CIM query first (Modern standard, PS 5.1 & PS 7+)
            if (Get-Command -Name Get-CimInstance -ErrorAction SilentlyContinue) {
                $filter = "DeviceID = '$cleanDrive'"
                $diskInfo = Get-CimInstance -ClassName Win32_LogicalDisk -Filter $filter -ErrorAction Stop
            }
        }
        catch {
            # Fallback to WMI or .NET DriveInfo below
        }

        try {
            # Fallback to .NET DriveInfo if CIM returned null
            if (-not $diskInfo) {
                $netDrive = [System.IO.DriveInfo]::GetDrives() | Where-Object { $_.Name.StartsWith($cleanDrive, [System.StringComparison]::OrdinalIgnoreCase) }
                if ($netDrive) {
                    $totalBytes = $netDrive.TotalSize
                    $freeBytes  = $netDrive.AvailableFreeSpace
                    $usedBytes  = $totalBytes - $freeBytes
                    $freePct    = if ($totalBytes -gt 0) { [math]::Round(($freeBytes / $totalBytes) * 100, 2) } else { 0 }
                    $usedPct    = if ($totalBytes -gt 0) { [math]::Round(($usedBytes / $totalBytes) * 100, 2) } else { 0 }

                    $results.Add([PSCustomObject]@{
                        DriveLetter     = $cleanDrive
                        VolumeName      = $netDrive.VolumeLabel
                        FileSystem      = $netDrive.DriveFormat
                        DriveType       = $netDrive.DriveType.ToString()
                        TotalBytes      = $totalBytes
                        TotalGB         = [math]::Round($totalBytes / 1GB, 2)
                        UsedBytes       = $usedBytes
                        UsedGB          = [math]::Round($usedBytes / 1GB, 2)
                        FreeBytes       = $freeBytes
                        FreeGB          = [math]::Round($freeBytes / 1GB, 2)
                        FreePercent     = $freePct
                        UsedPercent     = $usedPct
                        IsLowSpace      = ($freePct -lt 15.0)
                        IsCriticalSpace = ($freePct -lt 10.0)
                    })
                    continue
                }
            }

            if ($diskInfo) {
                $totalBytes = [int64]$diskInfo.Size
                $freeBytes  = [int64]$diskInfo.FreeSpace
                $usedBytes  = $totalBytes - $freeBytes
                $freePct    = if ($totalBytes -gt 0) { [math]::Round(($freeBytes / $totalBytes) * 100, 2) } else { 0 }
                $usedPct    = if ($totalBytes -gt 0) { [math]::Round(($usedBytes / $totalBytes) * 100, 2) } else { 0 }

                $results.Add([PSCustomObject]@{
                    DriveLetter     = $cleanDrive
                    VolumeName      = $diskInfo.VolumeName
                    FileSystem      = $diskInfo.FileSystem
                    DriveType       = switch ($diskInfo.DriveType) {
                        2 { "Removable" }
                        3 { "Fixed Local Disk" }
                        4 { "Network Drive" }
                        5 { "Compact Disc" }
                        default { "Unknown" }
                    }
                    TotalBytes      = $totalBytes
                    TotalGB         = [math]::Round($totalBytes / 1GB, 2)
                    UsedBytes       = $usedBytes
                    UsedGB          = [math]::Round($usedBytes / 1GB, 2)
                    FreeBytes       = $freeBytes
                    FreeGB          = [math]::Round($freeBytes / 1GB, 2)
                    FreePercent     = $freePct
                    UsedPercent     = $usedPct
                    IsLowSpace      = ($freePct -lt 15.0)
                    IsCriticalSpace = ($freePct -lt 10.0)
                })
            }
            else {
                Write-DiskLog -Message "Drive $cleanDrive could not be queried or does not exist." -Level "WARN"
            }
        }
        catch {
            Register-DiskScanError -Path $cleanDrive -ErrorType "DriveQueryFailure" -ErrorMessage $_.Exception.Message
        }
    }

    return $results.ToArray()
}

Export-ModuleMember -Function Get-DiskSpaceOverview
