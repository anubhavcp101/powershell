# =========================================================================
# Module: ReportGenerator.psm1
# Windows Server Disk Space Management & Analysis Framework
# Generates Executive HTML Reports and Comprehensive CSV Exports
# =========================================================================

Set-StrictMode -Version 2.0

function Export-DiskAnalysisReports {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [PSCustomObject]$AnalysisData,

        [Parameter(Mandatory = $false)]
        [string]$OutputDirectory,

        [Parameter(Mandatory = $false)]
        [string]$ReportPrefix = "DiskSpaceAnalysis"
    )

    if ([string]::IsNullOrWhiteSpace($OutputDirectory)) {
        $OutputDirectory = Join-Path -Path $PSScriptRoot -ChildPath "..\Reports"
    }

    if (-not (Test-Path -Path $OutputDirectory)) {
        [void](New-Item -ItemType Directory -Path $OutputDirectory -Force)
    }

    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $runFolder = Join-Path -Path $OutputDirectory -ChildPath "$($ReportPrefix)_$timestamp"
    [void](New-Item -ItemType Directory -Path $runFolder -Force)

    Write-DiskLog -Message "Exporting analysis reports to folder: $runFolder" -Level "INFO"

    # 1. Export CSV Reports
    $csvFiles = @{}

    # Category A: Potential Cleanup Candidates
    $catAPath = Join-Path -Path $runFolder -ChildPath "CategoryA_Candidates.csv"
    $AnalysisData.Classification.CategoryA | Export-Csv -Path $catAPath -NoTypeInformation -Encoding UTF8
    $csvFiles["CategoryA"] = $catAPath

    # Category B: Manual Investigation Required
    $catBPath = Join-Path -Path $runFolder -ChildPath "CategoryB_ManualInvestigation.csv"
    $AnalysisData.Classification.CategoryB | Export-Csv -Path $catBPath -NoTypeInformation -Encoding UTF8
    $csvFiles["CategoryB"] = $catBPath

    # Category C: Protected Files
    $catCPath = Join-Path -Path $runFolder -ChildPath "CategoryC_Protected.csv"
    $AnalysisData.Classification.CategoryC | Export-Csv -Path $catCPath -NoTypeInformation -Encoding UTF8
    $csvFiles["CategoryC"] = $catCPath

    # Large Files
    $largePath = Join-Path -Path $runFolder -ChildPath "LargeFiles.csv"
    $AnalysisData.Classification.LargeFiles | Export-Csv -Path $largePath -NoTypeInformation -Encoding UTF8
    $csvFiles["LargeFiles"] = $largePath

    # Old Files
    $oldPath = Join-Path -Path $runFolder -ChildPath "OldFiles.csv"
    $AnalysisData.Classification.OldFiles | Export-Csv -Path $oldPath -NoTypeInformation -Encoding UTF8
    $csvFiles["OldFiles"] = $oldPath

    # Directory Summary
    $dirSummaryPath = Join-Path -Path $runFolder -ChildPath "DirectorySummary.csv"
    $AnalysisData.DirectorySummary.AllDirectories | Export-Csv -Path $dirSummaryPath -NoTypeInformation -Encoding UTF8
    $csvFiles["DirectorySummary"] = $dirSummaryPath

    # Extension Summary
    $extSummaryPath = Join-Path -Path $runFolder -ChildPath "ExtensionSummary.csv"
    $AnalysisData.ExtensionSummary | Export-Csv -Path $extSummaryPath -NoTypeInformation -Encoding UTF8
    $csvFiles["ExtensionSummary"] = $extSummaryPath

    # Scan Errors and Inaccessible Paths
    $errorsPath = Join-Path -Path $runFolder -ChildPath "ScanErrors.csv"
    $AnalysisData.ScanErrors | Export-Csv -Path $errorsPath -NoTypeInformation -Encoding UTF8
    $csvFiles["ScanErrors"] = $errorsPath

    # All Discovered Files (capped by MaxRows setting to prevent memory starvation)
    $allFilesPath = Join-Path -Path $runFolder -ChildPath "AllDiscoveredFiles.csv"
    $maxRows = if ($AnalysisData.Config.Reporting.MaxCsvFileExportRows) { $AnalysisData.Config.Reporting.MaxCsvFileExportRows } else { 500000 }
    $AnalysisData.AllFiles | Select-Object -First $maxRows | Export-Csv -Path $allFilesPath -NoTypeInformation -Encoding UTF8
    $csvFiles["AllDiscoveredFiles"] = $allFilesPath

    # 2. Generate Executive HTML Report
    $htmlPath = Join-Path -Path $runFolder -ChildPath "Executive_DiskSpace_Report.html"
    $htmlContent = New-ExecutiveHtmlContent -Data $AnalysisData
    [System.IO.File]::WriteAllText($htmlPath, $htmlContent, [System.Text.Encoding]::UTF8)

    Write-DiskLog -Message "Executive HTML Report successfully generated: $htmlPath" -Level "SUCCESS"

    return [PSCustomObject]@{
        ReportFolder   = $runFolder
        HtmlReport     = $htmlPath
        CsvReports     = $csvFiles
    }
}

function New-ExecutiveHtmlContent {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [PSCustomObject]$Data
    )

    $sys = $Data.SystemInfo
    $disk = $Data.DiskOverview[0]
    $freeClass = if ($disk.FreePercent -lt 10) { "metric-danger" } elseif ($disk.FreePercent -lt 20) { "metric-warning" } else { "metric-success" }

    # Build Opportunities rows
    $oppRows = ""
    foreach ($opp in $Data.Classification.CleanupOpportunities) {
        $oppRows += "<tr><td><strong>$($opp.OpportunityCategory)</strong></td><td>$($opp.FileCount)</td><td>$($opp.PotentialSpaceMB) MB</td><td>$($opp.PotentialSpaceGB) GB</td><td><span class='badge badge-info'>Review Required</span></td></tr>"
    }
    if ([string]::IsNullOrWhiteSpace($oppRows)) {
        $oppRows = "<tr><td colspan='5' class='text-center'>No categorized cleanup opportunities identified meeting age thresholds.</td></tr>"
    }

    # Build Top 30 Largest Files rows
    $topFileRows = ""
    $top30Files = $Data.AllFiles | Sort-Object -Property Length -Descending | Select-Object -First 30
    $fIndex = 1
    foreach ($tf in $top30Files) {
        $topFileRows += "<tr><td>$fIndex</td><td class='code-path' title='$($tf.FullName)'>$($tf.Name)</td><td>$($tf.LengthMB) MB</td><td>$($tf.AgeDays)</td><td class='code-path'>$($tf.DirectoryName)</td></tr>"
        $fIndex++
    }

    # Build Top 30 Largest Directories rows
    $topDirRows = ""
    $dIndex = 1
    foreach ($td in $Data.DirectorySummary.TopLargestDirectories) {
        $warnBadge = if ($td.IsHighFileCount) { "<span class='badge badge-danger'>High File Count</span>" } else { "" }
        $topDirRows += "<tr><td>$dIndex</td><td class='code-path'>$($td.DirectoryPath) $warnBadge</td><td>$($td.TotalMB) MB</td><td>$($td.TotalGB) GB</td><td>$($td.FileCount)</td></tr>"
        $dIndex++
    }

    # Build Extension Distribution rows
    $extRows = ""
    $topExts = $Data.ExtensionSummary | Select-Object -First 15
    foreach ($te in $topExts) {
        $extRows += "<tr><td><code>$($te.Extension)</code></td><td>$($te.FileCount)</td><td>$($te.TotalMB) MB</td><td>$($te.TotalGB) GB</td></tr>"
    }

    # Windows Analysis Special Modules summary text
    $dismRecom = if ($Data.WindowsAnalysis.ComponentStore) { $Data.WindowsAnalysis.ComponentStore.ComponentCleanupRecom } else { "Not Analyzed" }
    $vssAlloc  = if ($Data.WindowsAnalysis.ShadowCopies) { $Data.WindowsAnalysis.ShadowCopies.AllocatedSpaceMB } else { "N/A" }
    $iisSizeMB = if ($Data.WindowsAnalysis.IISLogs -and $Data.WindowsAnalysis.IISLogs.Exists) { "$($Data.WindowsAnalysis.IISLogs.TotalMB) MB ($($Data.WindowsAnalysis.IISLogs.OldFilesMB) MB older than 90d)" } else { "Not Installed / No Logs" }
    $wuCacheMB = if ($Data.WindowsAnalysis.UpdateCache -and $Data.WindowsAnalysis.UpdateCache.Exists) { "$($Data.WindowsAnalysis.UpdateCache.TotalMB) MB" } else { "0 MB" }

    $html = @"
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Executive Disk Space Analysis - $($sys.ComputerName)</title>
    <style>
        :root {
            --primary: #1e3a8a;
            --secondary: #0284c7;
            --success: #059669;
            --warning: #d97706;
            --danger: #dc2626;
            --bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #0f172a;
            --text-muted: #64748b;
            --border: #e2e8f0;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: var(--bg);
            color: var(--text-dark);
            margin: 0;
            padding: 24px;
            line-height: 1.5;
        }
        .header {
            background: linear-gradient(135deg, #1e293b, #0f172a);
            color: #ffffff;
            padding: 24px 32px;
            border-radius: 12px;
            margin-bottom: 24px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
        }
        .header h1 { margin: 0 0 8px 0; font-size: 26px; }
        .header p { margin: 0; color: #94a3b8; font-size: 14px; }
        .disclaimer-banner {
            background-color: #fef2f2;
            border-left: 6px solid var(--danger);
            padding: 14px 20px;
            margin-bottom: 24px;
            border-radius: 6px;
            font-size: 13px;
            color: #991b1b;
        }
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }
        .metric-card {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 10px;
            border: 1px solid var(--border);
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .metric-title { font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; color: var(--text-muted); font-weight: 600; margin-bottom: 8px; }
        .metric-value { font-size: 28px; font-weight: 700; color: var(--text-dark); }
        .metric-success { color: var(--success); }
        .metric-warning { color: var(--warning); }
        .metric-danger { color: var(--danger); }
        .section-card {
            background: var(--card-bg);
            border-radius: 10px;
            border: 1px solid var(--border);
            padding: 24px;
            margin-bottom: 24px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .section-title { font-size: 18px; font-weight: 700; margin-top: 0; margin-bottom: 16px; border-bottom: 2px solid var(--border); padding-bottom: 8px; }
        table { width: 100%; border-collapse: collapse; font-size: 13px; text-align: left; }
        th, td { padding: 10px 14px; border-bottom: 1px solid var(--border); }
        th { background-color: #f1f5f9; color: var(--text-dark); font-weight: 600; }
        tr:hover { background-color: #f8fafc; }
        .code-path { font-family: Consolas, "Courier New", monospace; font-size: 12px; word-break: break-all; }
        .badge { display: inline-block; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; }
        .badge-info { background: #e0f2fe; color: #0369a1; }
        .badge-danger { background: #fee2e2; color: #b91c1c; }
        .badge-success { background: #dcfce7; color: #15803d; }
        .recommendation-list { padding-left: 20px; }
        .recommendation-list li { margin-bottom: 10px; font-size: 14px; }
    </style>
</head>
<body>

    <div class="header">
        <h1>Windows Server Disk Space Analysis & Health Report</h1>
        <p>Target Server: <strong>$($sys.ComputerName)</strong> | OS: <strong>$($sys.OSVersion)</strong> | PowerShell: <strong>$($sys.PSVersion)</strong> | Scan Date: <strong>$($sys.ScanTimestamp)</strong> | Duration: <strong>$($sys.ScanDuration)</strong></p>
    </div>

    <div class="disclaimer-banner">
        <strong>CRITICAL SAFETY & AUDIT NOTICE:</strong> This framework operates strictly in <strong>read-only mode</strong>. No files were deleted, compressed, moved, or altered. The reported <em>Potential Cleanup Opportunities</em> are theoretical targets identified via configurable age thresholds and file categories. Any cleanup action requires rigorous verification and testing by a certified Systems Administrator.
    </div>

    <div class="metrics-grid">
        <div class="metric-card">
            <div class="metric-title">Drive Capacity ($($disk.DriveLetter))</div>
            <div class="metric-value">$($disk.TotalGB) GB</div>
        </div>
        <div class="metric-card">
            <div class="metric-title">Used Disk Space</div>
            <div class="metric-value">$($disk.UsedGB) GB</div>
        </div>
        <div class="metric-card">
            <div class="metric-title">Free Disk Space</div>
            <div class="metric-value $freeClass">$($disk.FreeGB) GB ($($disk.FreePercent)%)</div>
        </div>
        <div class="metric-card">
            <div class="metric-title">Total Discovered Files</div>
            <div class="metric-value">$($Data.AllFiles.Count)</div>
        </div>
        <div class="metric-card">
            <div class="metric-title">Potential Cleanup Space</div>
            <div class="metric-value metric-warning">$($Data.Classification.TotalPotentialCleanupGB) GB</div>
        </div>
    </div>

    <div class="section-card">
        <h2 class="section-title">Potential Cleanup Opportunities Summary (Subject to Administrator Review)</h2>
        <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 16px;">
            Estimated disk space consumed by files meeting retention policies (e.g. old logs, archived crash dumps, expired temporary files).
        </p>
        <table>
            <thead>
                <tr>
                    <th>Category</th>
                    <th>File Count</th>
                    <th>Potential Space (MB)</th>
                    <th>Potential Space (GB)</th>
                    <th>Action Required</th>
                </tr>
            </thead>
            <tbody>
                $oppRows
            </tbody>
        </table>
    </div>

    <div class="section-card">
        <h2 class="section-title">Windows Server Subsystem Discovery</h2>
        <table>
            <thead>
                <tr>
                    <th>Subsystem / Component</th>
                    <th>Status / Metrics</th>
                    <th>Engineering Guidance</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>Windows Component Store (WinSxS)</strong></td>
                    <td>Cleanup Recommended: <strong>$dismRecom</strong></td>
                    <td>Evaluate using native DISM maintenance if recommended by Windows.</td>
                </tr>
                <tr>
                    <td><strong>Volume Shadow Storage (VSS)</strong></td>
                    <td>Allocated Space: <strong>$vssAlloc</strong></td>
                    <td>Review backup retention schedule and shadow copy max storage limits.</td>
                </tr>
                <tr>
                    <td><strong>Windows Update Cache</strong></td>
                    <td>Size: <strong>$wuCacheMB</strong></td>
                    <td>Staging files for completed Windows Updates.</td>
                </tr>
                <tr>
                    <td><strong>IIS Web Server Logs</strong></td>
                    <td>Size: <strong>$iisSizeMB</strong></td>
                    <td>Configure log rotation and centralized log shipping or automated archival.</td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="section-card">
        <h2 class="section-title">Top 30 Largest Discovered Files</h2>
        <table>
            <thead>
                <tr>
                    <th style="width: 40px;">#</th>
                    <th>File Name</th>
                    <th>Size (MB)</th>
                    <th>Age (Days)</th>
                    <th>Directory</th>
                </tr>
            </thead>
            <tbody>
                $topFileRows
            </tbody>
        </table>
    </div>

    <div class="section-card">
        <h2 class="section-title">Top 30 Largest Directories</h2>
        <table>
            <thead>
                <tr>
                    <th style="width: 40px;">#</th>
                    <th>Directory Path</th>
                    <th>Total Size (MB)</th>
                    <th>Total Size (GB)</th>
                    <th>File Count</th>
                </tr>
            </thead>
            <tbody>
                $topDirRows
            </tbody>
        </table>
    </div>

    <div class="section-card">
        <h2 class="section-title">Disk Usage by File Extension (Top 15)</h2>
        <table>
            <thead>
                <tr>
                    <th>Extension</th>
                    <th>File Count</th>
                    <th>Total Space (MB)</th>
                    <th>Total Space (GB)</th>
                </tr>
            </thead>
            <tbody>
                $extRows
            </tbody>
        </table>
    </div>

    <div class="section-card">
        <h2 class="section-title">Recommendations</h2>
        <ul class="recommendation-list">
            <li><strong>Audit Category A Candidates:</strong> Review the detailed CSV <code>CategoryA_Candidates.csv</code> for expired logs and diagnostic traces. Verify with application owners prior to scheduling cleanup tasks.</li>
            <li><strong>IIS Log Retention:</strong> For systems hosting active web services, configure automated log compression and shipping to centralized storage (Splunk, Elastic, or Azure Monitor).</li>
            <li><strong>Monitor High File Count Folders:</strong> Directories with over 5,000 files can cause NTFS performance degradation and slow antivirus indexing scans.</li>
            <li><strong>Component Store Maintenance:</strong> If DISM analysis recommended cleanup, plan maintenance during a scheduled maintenance window using standard Windows Server servicing commands.</li>
            <li><strong>Review Inaccessible Locations:</strong> Consult <code>ScanErrors.csv</code> to verify if system security or permission boundaries restricted enumeration in proprietary directories.</li>
        </ul>
    </div>

</body>
</html>
"@

    return $html
}

Export-ModuleMember -Function Export-DiskAnalysisReports, New-ExecutiveHtmlContent
