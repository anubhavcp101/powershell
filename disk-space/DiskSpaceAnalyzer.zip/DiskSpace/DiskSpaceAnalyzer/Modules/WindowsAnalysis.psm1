# =========================================================================
# Module: WindowsAnalysis.psm1
# Windows Server Disk Space Management & Analysis Framework
# Specialized native Windows discovery modules (Read-Only)
# ComponentStore, SoftwareDistribution, WER, IIS, Dumps, VSS, Pagefile
# =========================================================================

Set-StrictMode -Version 2.0

function Get-WindowsComponentStoreAnalysis {
    [CmdletBinding()]
    param()

    Write-DiskLog -Message "Analyzing Windows Component Store (DISM /AnalyzeComponentStore - Strictly Read-Only)..." -Level "INFO"

    $result = [PSCustomObject]@{
        ComponentStorePath     = "C:\Windows\WinSxS"
        ComponentStoreSizeGB   = 0
        ReportedWinSxSSizeMB   = "N/A"
        ReclaimablePackagesMB  = "N/A"
        ComponentCleanupRecom  = "N/A"
        RawOutput              = ""
        Status                 = "Completed"
    }

    if (Test-Path -Path "C:\Windows\WinSxS") {
        try {
            $dismPath = "$env:SystemRoot\System32\dism.exe"
            if (Test-Path -Path $dismPath) {
                # Execute read-only analyze command safely with timeout/redirection
                $pinfo = New-Object System.Diagnostics.ProcessStartInfo
                $pinfo.FileName = $dismPath
                $pinfo.Arguments = "/Online /Cleanup-Image /AnalyzeComponentStore /Format:Table"
                $pinfo.RedirectStandardOutput = $true
                $pinfo.RedirectStandardError = $true
                $pinfo.UseShellExecute = $false
                $pinfo.CreateNoWindow = $true

                $process = [System.Diagnostics.Process]::Start($pinfo)
                $stdout = $process.StandardOutput.ReadToEnd()
                $stderr = $process.StandardError.ReadToEnd()
                [void]$process.WaitForExit(180000) # 3 min maximum wait

                $result.RawOutput = $stdout
                if ($stdout -match 'Component Store \(WinSxS\) Actual Size\s*:\s*([0-9\.]+)\s*([A-Za-z]+)') {
                    $result.ReportedWinSxSSizeMB = "$($Matches[1]) $($Matches[2])"
                }
                if ($stdout -match 'Component Store Cleanup Recommended\s*:\s*([A-Za-z]+)') {
                    $result.ComponentCleanupRecom = $Matches[1]
                }
            }
        }
        catch {
            Register-DiskScanError -Path "C:\Windows\WinSxS" -ErrorType "DISMAnalysisError" -ErrorMessage $_.Exception.Message
            $result.Status = "Error: $($_.Exception.Message)"
        }
    }
    else {
        $result.Status = "WinSxS not found"
    }

    return $result
}

function Get-WindowsUpdateCacheAnalysis {
    [CmdletBinding()]
    param()

    $cachePath = "C:\Windows\SoftwareDistribution\Download"
    Write-DiskLog -Message "Analyzing Windows Update Download Cache at $cachePath..." -Level "INFO"

    $totalBytes = [int64]0
    $fileCount  = 0
    $oldestDate = $null
    $newestDate = $null

    if (Test-Path -Path $cachePath) {
        try {
            $files = [System.IO.DirectoryInfo]::new($cachePath).EnumerateFiles("*", [System.IO.SearchOption]::AllDirectories)
            foreach ($f in $files) {
                $totalBytes += $f.Length
                $fileCount++
                if ($null -eq $oldestDate -or $f.LastWriteTime -lt $oldestDate) { $oldestDate = $f.LastWriteTime }
                if ($null -eq $newestDate -or $f.LastWriteTime -gt $newestDate) { $newestDate = $f.LastWriteTime }
            }
        }
        catch {
            Register-DiskScanError -Path $cachePath -ErrorType "UpdateCacheAnalysisError" -ErrorMessage $_.Exception.Message
        }
    }

    return [PSCustomObject]@{
        Path           = $cachePath
        Exists         = (Test-Path -Path $cachePath)
        TotalBytes     = $totalBytes
        TotalMB        = [math]::Round($totalBytes / 1MB, 2)
        TotalGB        = [math]::Round($totalBytes / 1GB, 3)
        FileCount      = $fileCount
        OldestFileDate = $oldestDate
        NewestFileDate = $newestDate
        Note           = "Windows Update patch staging cache. Historical files may be cleared via Disk Cleanup / native maintenance."
    }
}

function Get-WindowsWERAnalysis {
    [CmdletBinding()]
    param()

    $werPath = "C:\ProgramData\Microsoft\Windows\WER"
    Write-DiskLog -Message "Analyzing Windows Error Reporting (WER) at $werPath..." -Level "INFO"

    $totalBytes = [int64]0
    $fileCount  = 0
    $dumpCount  = 0

    if (Test-Path -Path $werPath) {
        try {
            $files = [System.IO.DirectoryInfo]::new($werPath).EnumerateFiles("*", [System.IO.SearchOption]::AllDirectories)
            foreach ($f in $files) {
                $totalBytes += $f.Length
                $fileCount++
                if ($f.Extension -in @('.dmp', '.mdmp', '.hdmp')) {
                    $dumpCount++
                }
            }
        }
        catch {
            Register-DiskScanError -Path $werPath -ErrorType "WERAnalysisError" -ErrorMessage $_.Exception.Message
        }
    }

    return [PSCustomObject]@{
        Path        = $werPath
        Exists      = (Test-Path -Path $werPath)
        TotalBytes  = $totalBytes
        TotalMB     = [math]::Round($totalBytes / 1MB, 2)
        TotalGB     = [math]::Round($totalBytes / 1GB, 3)
        FileCount   = $fileCount
        DumpCount   = $dumpCount
        Note        = "Archived crash reports and user-mode dumps."
    }
}

function Get-IISLogAnalysis {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [int]$RetentionDays = 90
    )

    $iisPath = "C:\inetpub\logs\LogFiles"
    Write-DiskLog -Message "Analyzing IIS Web Server Logs at $iisPath..." -Level "INFO"

    $totalBytes = [int64]0
    $fileCount  = 0
    $oldFilesBytes = [int64]0
    $oldFilesCount = 0
    $sites = [System.Collections.Generic.List[PSObject]]::new()
    $now = Get-Date

    if (Test-Path -Path $iisPath) {
        try {
            $siteDirs = [System.IO.DirectoryInfo]::new($iisPath).EnumerateDirectories()
            foreach ($s in $siteDirs) {
                $siteBytes = [int64]0
                $siteFiles = 0
                $siteOldBytes = [int64]0
                $siteOldFiles = 0

                foreach ($f in $s.EnumerateFiles("*.log")) {
                    $len = $f.Length
                    $siteBytes += $len
                    $siteFiles++
                    $age = ($now - $f.LastWriteTime).TotalDays
                    if ($age -ge $RetentionDays) {
                        $siteOldBytes += $len
                        $siteOldFiles++
                    }
                }

                $totalBytes += $siteBytes
                $fileCount  += $siteFiles
                $oldFilesBytes += $siteOldBytes
                $oldFilesCount += $siteOldFiles

                $sites.Add([PSCustomObject]@{
                    SiteDirectory = $s.Name
                    TotalMB       = [math]::Round($siteBytes / 1MB, 2)
                    TotalFiles    = $siteFiles
                    OldFilesCount = $siteOldFiles
                    OldFilesMB    = [math]::Round($siteOldBytes / 1MB, 2)
                })
            }
        }
        catch {
            Register-DiskScanError -Path $iisPath -ErrorType "IISLogAnalysisError" -ErrorMessage $_.Exception.Message
        }
    }

    return [PSCustomObject]@{
        Path           = $iisPath
        Exists         = (Test-Path -Path $iisPath)
        TotalBytes     = $totalBytes
        TotalMB        = [math]::Round($totalBytes / 1MB, 2)
        TotalGB        = [math]::Round($totalBytes / 1GB, 3)
        FileCount      = $fileCount
        OldFilesBytes  = $oldFilesBytes
        OldFilesMB     = [math]::Round($oldFilesBytes / 1MB, 2)
        OldFilesGB     = [math]::Round($oldFilesBytes / 1GB, 3)
        OldFilesCount  = $oldFilesCount
        SitesSummary   = $sites.ToArray()
    }
}

function Get-CrashDumpAnalysis {
    [CmdletBinding()]
    param()

    Write-DiskLog -Message "Analyzing System Crash Dumps and LiveKernelReports..." -Level "INFO"

    $dumpLocations = @(
        "C:\Windows\Minidump",
        "C:\Windows\MEMORY.DMP",
        "C:\Windows\LiveKernelReports"
    )

    $dumpFiles = [System.Collections.Generic.List[PSObject]]::new()
    $totalDumpBytes = [int64]0

    foreach ($loc in $dumpLocations) {
        if (Test-Path -LiteralPath $loc) {
            try {
                if ([System.IO.File]::Exists($loc)) {
                    $fi = [System.IO.FileInfo]::new($loc)
                    $totalDumpBytes += $fi.Length
                    $dumpFiles.Add([PSCustomObject]@{
                        Path         = $fi.FullName
                        Name         = $fi.Name
                        SizeMB       = [math]::Round($fi.Length / 1MB, 2)
                        LastModified = $fi.LastWriteTime
                        Type         = "Kernel Complete Dump"
                    })
                }
                elseif ([System.IO.Directory]::Exists($loc)) {
                    $di = [System.IO.DirectoryInfo]::new($loc)
                    foreach ($f in $di.EnumerateFiles("*", [System.IO.SearchOption]::AllDirectories)) {
                        $totalDumpBytes += $f.Length
                        $dumpFiles.Add([PSCustomObject]@{
                            Path         = $f.FullName
                            Name         = $f.Name
                            SizeMB       = [math]::Round($f.Length / 1MB, 2)
                            LastModified = $f.LastWriteTime
                            Type         = if ($loc -match 'Minidump') { "Minidump" } else { "LiveKernelReport" }
                        })
                    }
                }
            }
            catch {
                Register-DiskScanError -Path $loc -ErrorType "DumpInspectError" -ErrorMessage $_.Exception.Message
            }
        }
    }

    return [PSCustomObject]@{
        TotalDumpBytes = $totalDumpBytes
        TotalDumpMB    = [math]::Round($totalDumpBytes / 1MB, 2)
        TotalDumpGB    = [math]::Round($totalDumpBytes / 1GB, 3)
        DumpCount      = $dumpFiles.Count
        DumpFiles      = $dumpFiles.ToArray()
    }
}

function Get-ShadowCopyAnalysis {
    [CmdletBinding()]
    param()

    Write-DiskLog -Message "Discovering Volume Shadow Copies (VSS - Strictly Read-Only)..." -Level "INFO"

    $result = [PSCustomObject]@{
        AllocatedSpaceMB = "N/A"
        UsedSpaceMB      = "N/A"
        MaxSpaceMB       = "N/A"
        RawOutput        = ""
        Status           = "Completed"
    }

    try {
        $vssadmin = "$env:SystemRoot\System32\vssadmin.exe"
        if (Test-Path -Path $vssadmin) {
            $pinfo = New-Object System.Diagnostics.ProcessStartInfo
            $pinfo.FileName = $vssadmin
            $pinfo.Arguments = "list shadowstorage"
            $pinfo.RedirectStandardOutput = $true
            $pinfo.RedirectStandardError = $true
            $pinfo.UseShellExecute = $false
            $pinfo.CreateNoWindow = $true

            $process = [System.Diagnostics.Process]::Start($pinfo)
            $stdout = $process.StandardOutput.ReadToEnd()
            [void]$process.WaitForExit(30000)

            $result.RawOutput = $stdout
            if ($stdout -match 'Used Shadow Copy Storage space:\s*([0-9\.]+)\s*([A-Za-z]+)') {
                $result.UsedSpaceMB = "$($Matches[1]) $($Matches[2])"
            }
            if ($stdout -match 'Allocated Shadow Copy Storage space:\s*([0-9\.]+)\s*([A-Za-z]+)') {
                $result.AllocatedSpaceMB = "$($Matches[1]) $($Matches[2])"
            }
            if ($stdout -match 'Maximum Shadow Copy Storage space:\s*([0-9\.]+)\s*([A-Za-z]+)') {
                $result.MaxSpaceMB = "$($Matches[1]) $($Matches[2])"
            }
        }
    }
    catch {
        Register-DiskScanError -Path "VSS Storage" -ErrorType "VSSQueryError" -ErrorMessage $_.Exception.Message
        $result.Status = "Error: $($_.Exception.Message)"
    }

    return $result
}

function Get-PagefileAndSystemFilesAnalysis {
    [CmdletBinding()]
    param()

    Write-DiskLog -Message "Discovering Pagefile, Swapfile, and System files configuration..." -Level "INFO"

    $pagefiles = [System.Collections.Generic.List[PSObject]]::new()
    $systemFiles = @("C:\pagefile.sys", "C:\swapfile.sys", "C:\hiberfil.sys")
    $sysFileDetails = [System.Collections.Generic.List[PSObject]]::new()

    foreach ($sf in $systemFiles) {
        if (Test-Path -LiteralPath $sf) {
            try {
                $fi = [System.IO.FileInfo]::new($sf)
                $sysFileDetails.Add([PSCustomObject]@{
                    Path   = $sf
                    Name   = $fi.Name
                    SizeMB = [math]::Round($fi.Length / 1MB, 2)
                    SizeGB = [math]::Round($fi.Length / 1GB, 3)
                    Status = "Present (System Managed)"
                })
            }
            catch {
                $sysFileDetails.Add([PSCustomObject]@{
                    Path   = $sf
                    Name   = [System.IO.Path]::GetFileName($sf)
                    SizeMB = 0
                    SizeGB = 0
                    Status = "Present (Locked by Windows Kernel)"
                })
            }
        }
    }

    try {
        if (Get-Command -Name Get-CimInstance -ErrorAction SilentlyContinue) {
            $pfUsages = Get-CimInstance -ClassName Win32_PageFileUsage -ErrorAction SilentlyContinue
            foreach ($pf in $pfUsages) {
                $pagefiles.Add([PSCustomObject]@{
                    Name          = $pf.Name
                    AllocatedMB   = $pf.AllocatedBaseSize
                    CurrentUsageMB= $pf.CurrentUsage
                    PeakUsageMB   = $pf.PeakUsage
                })
            }
        }
    }
    catch {
        # Fallback or record
    }

    return [PSCustomObject]@{
        SystemFiles = $sysFileDetails.ToArray()
        PageFiles   = $pagefiles.ToArray()
    }
}

Export-ModuleMember -Function Get-WindowsComponentStoreAnalysis,
    Get-WindowsUpdateCacheAnalysis,
    Get-WindowsWERAnalysis,
    Get-IISLogAnalysis,
    Get-CrashDumpAnalysis,
    Get-ShadowCopyAnalysis,
    Get-PagefileAndSystemFilesAnalysis
