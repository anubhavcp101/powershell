# =========================================================================
# Module: FileClassification.psm1
# Windows Server Disk Space Management & Analysis Framework
# Multi-criteria classification engine (Directory, Extension, Age, Dependencies)
# =========================================================================

Set-StrictMode -Version 2.0

function Invoke-FileClassification {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [array]$FileList,

        [Parameter(Mandatory = $true)]
        [hashtable]$Config
    )

    $ageThresholds = $Config.AgeThresholds
    $extCats       = $Config.ExtensionCategories
    $protectedLocs = $Config.ProtectedLocations
    $largeThresholdMB = if ($Config.Thresholds.LargeFileThresholdMB) { $Config.Thresholds.LargeFileThresholdMB } else { 100 }

    $categoryA = [System.Collections.Generic.List[PSObject]]::new()
    $categoryB = [System.Collections.Generic.List[PSObject]]::new()
    $categoryC = [System.Collections.Generic.List[PSObject]]::new()
    $largeFiles = [System.Collections.Generic.List[PSObject]]::new()
    $oldFiles   = [System.Collections.Generic.List[PSObject]]::new()

    # Pre-build lookup sets using 1-arg constructor with StringComparer to ensure 100% PS 5.1 compatibility
    $loggingExts   = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    if ($extCats.LoggingAndTracing) { foreach ($x in $extCats.LoggingAndTracing) { [void]$loggingExts.Add($x) } }

    $crashExts     = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    if ($extCats.CrashDumps) { foreach ($x in $extCats.CrashDumps) { [void]$crashExts.Add($x) } }

    $tempExts      = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    if ($extCats.TemporaryFiles) { foreach ($x in $extCats.TemporaryFiles) { [void]$tempExts.Add($x) } }

    $installerExts = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    if ($extCats.InstallerUpdates) { foreach ($x in $extCats.InstallerUpdates) { [void]$installerExts.Add($x) } }

    $archiveExts   = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    if ($extCats.Archives) { foreach ($x in $extCats.Archives) { [void]$archiveExts.Add($x) } }

    $databaseExts  = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    if ($extCats.DatabaseFiles) { foreach ($x in $extCats.DatabaseFiles) { [void]$databaseExts.Add($x) } }

    $virtualDiskExts = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    if ($extCats.VirtualDisks) { foreach ($x in $extCats.VirtualDisks) { [void]$virtualDiskExts.Add($x) } }

    foreach ($file in $FileList) {
        $path = $file.FullName
        $dir  = $file.DirectoryName
        $ext  = $file.Extension
        $age  = $file.AgeDays
        $mb   = $file.LengthMB

        # Large file tracking (independent of category)
        if ($mb -ge $largeThresholdMB) {
            $largeFiles.Add($file)
        }

        # Check if file falls under explicitly Protected Locations (Category C)
        $isProtected = $false
        $protectReason = ""

        # System managed files
        if ($path -match '(?i)\\(pagefile\.sys|swapfile\.sys|hiberfil\.sys|dumpstack\.log)$') {
            $isProtected = $true
            $protectReason = "System-managed core OS paging or crash telemetry file"
        }
        # WinSxS, Installer cache, System32\config, System Volume Information, etc.
        elseif ($path -match '(?i)\\Windows\\(WinSxS|Installer|System32\\config)(\\|$)' -or
                $path -match '(?i)\\System Volume Information(\\|$)' -or
                $path -match '(?i)\\(\$Recycle\.Bin|Recovery|Boot|EFI)(\\|$)' -or
                $path -match '(?i)\\Windows\\System32\\winevt\\Logs\\.*\.evtx$') {
            $isProtected = $true
            $protectReason = "Protected Windows Component Store / Installer Cache / Active System Event Logs / Registry Hive"
        }
        # Database & Virtual Disk files
        elseif ($databaseExts.Contains($ext) -or $virtualDiskExts.Contains($ext) -or $path -match '(?i)\\Microsoft SQL Server\\') {
            $isProtected = $true
            $protectReason = "Active Database (SQL/AD/Exchange) or Hyper-V Virtual Disk"
        }
        # Executable binaries and system drivers
        elseif ($ext -in @('.exe', '.dll', '.sys', '.drv', '.ocx', '.cpl', '.msc') -and $path -match '(?i)\\Windows\\(System32|SysWOW64)\\') {
            $isProtected = $true
            $protectReason = "Critical Operating System binary or device driver"
        }

        if ($isProtected) {
            $catItem = $file | Select-Object *, @{Name="Classification"; Expression={"Category C - Protected"}}, @{Name="ClassificationReason"; Expression={$protectReason}}
            $categoryC.Add($catItem)
            continue
        }

        # Category A: Potential Cleanup Candidates Evaluation
        $isCandidate = $false
        $candidateReason = ""
        $cleanupBucket = ""

        # 1. Crash Dumps older than threshold
        if ($crashExts.Contains($ext) -or $path -match '(?i)\\Windows\\(Minidump|LiveKernelReports)(\\|$)') {
            $threshold = if ($ageThresholds.Crash_Dumps) { $ageThresholds.Crash_Dumps } else { 90 }
            if ($age -ge $threshold) {
                $isCandidate = $true
                $candidateReason = "Historical crash dump exceeding retention ($age days >= $threshold days)"
                $cleanupBucket = "Crash Dumps"
            }
        }
        # 2. IIS Logs older than threshold
        elseif ($path -match '(?i)\\inetpub\\logs\\LogFiles\\') {
            $threshold = if ($ageThresholds.IIS_Logs) { $ageThresholds.IIS_Logs } else { 90 }
            if ($age -ge $threshold) {
                $isCandidate = $true
                $candidateReason = "Archived IIS W3C access log exceeding retention ($age days >= $threshold days)"
                $cleanupBucket = "IIS Logs"
            }
        }
        # 3. ETL Logs older than threshold
        elseif ($ext -eq '.etl') {
            $threshold = if ($ageThresholds.ETL_Logs) { $ageThresholds.ETL_Logs } else { 180 }
            if ($age -ge $threshold) {
                $isCandidate = $true
                $candidateReason = "Event Trace Log (ETL) exceeding retention ($age days >= $threshold days)"
                $cleanupBucket = "Old Logs"
            }
        }
        # 4. EVTX logs (non-protected / archived) older than threshold
        elseif ($ext -eq '.evtx') {
            $threshold = if ($ageThresholds.EVTX_Logs) { $ageThresholds.EVTX_Logs } else { 180 }
            if ($age -ge $threshold) {
                $isCandidate = $true
                $candidateReason = "Archived Windows Event Log exceeding retention ($age days >= $threshold days)"
                $cleanupBucket = "Old Logs"
            }
        }
        # 5. Temporary files older than threshold
        elseif ($tempExts.Contains($ext) -or $path -match '(?i)\\Windows\\Temp\\' -or $path -match '(?i)\\AppData\\Local\\Temp\\') {
            $threshold = if ($ageThresholds.Temporary_Files) { $ageThresholds.Temporary_Files } else { 14 }
            if ($age -ge $threshold) {
                $isCandidate = $true
                $candidateReason = "Temporary file exceeding threshold ($age days >= $threshold days)"
                $cleanupBucket = "Temporary Files"
            }
        }
        # 6. Windows Error Reporting (WER) archives
        elseif ($path -match '(?i)\\ProgramData\\Microsoft\\Windows\\WER\\') {
            $threshold = if ($ageThresholds.General_App_Logs) { $ageThresholds.General_App_Logs } else { 180 }
            if ($age -ge $threshold) {
                $isCandidate = $true
                $candidateReason = "Archived Windows Error Report ($age days >= $threshold days)"
                $cleanupBucket = "Historical Diagnostic Files"
            }
        }
        # 7. General logs (.log, .log.gz, .trace, .blg) older than threshold
        elseif ($loggingExts.Contains($ext)) {
            $threshold = if ($ageThresholds.General_App_Logs) { $ageThresholds.General_App_Logs } else { 180 }
            if ($age -ge $threshold) {
                $isCandidate = $true
                $candidateReason = "Rotated or inactive log file exceeding retention ($age days >= $threshold days)"
                $cleanupBucket = "Application Logs"
            }
        }

        if ($isCandidate) {
            $catItem = $file | Select-Object *,
                @{Name="Classification"; Expression={"Category A - Potential Cleanup Candidate"}},
                @{Name="ClassificationReason"; Expression={$candidateReason}},
                @{Name="CleanupBucket"; Expression={$cleanupBucket}}
            $categoryA.Add($catItem)
            $oldFiles.Add($file)
            continue
        }

        # Otherwise: Category B - Manual Investigation Required
        $investigationReason = "General file requiring administrative verification before action"
        if ($installerExts.Contains($ext)) {
            $investigationReason = "Installer or patch package (.msi/.msp/.cab/.wim/.esd). May be required for patching or repairs."
        }
        elseif ($archiveExts.Contains($ext)) {
            $investigationReason = "Compressed archive file. Verify ownership and contents."
        }
        elseif ($path -match '(?i)\\ProgramData\\') {
            $investigationReason = "Application configuration/data in ProgramData. Check host application lifecycle."
        }
        elseif ($path -match '(?i)\\Users\\') {
            $investigationReason = "User profile file. Verify user account status and profile retention policies."
        }

        $catItem = $file | Select-Object *,
            @{Name="Classification"; Expression={"Category B - Manual Investigation Required"}},
            @{Name="ClassificationReason"; Expression={$investigationReason}}
        $categoryB.Add($catItem)

        if ($age -ge $ageThresholds.Default_Old_Files) {
            $oldFiles.Add($file)
        }
    }

    # Aggregate Cleanup Opportunities Summary
    $opportunityMap = @{}
    foreach ($cand in $categoryA) {
        $bucket = if ($cand.CleanupBucket) { $cand.CleanupBucket } else { "Other Historical Files" }
        if (-not $opportunityMap.ContainsKey($bucket)) {
            $opportunityMap[$bucket] = [PSCustomObject]@{
                Category    = $bucket
                FileCount   = [int64]0
                TotalBytes  = [int64]0
            }
        }
        $opportunityMap[$bucket].FileCount += 1
        $opportunityMap[$bucket].TotalBytes += [int64]$cand.Length
    }

    $opportunities = [System.Collections.Generic.List[PSObject]]::new()
    $totalOpportunityBytes = [int64]0
    foreach ($k in $opportunityMap.Keys) {
        $entry = $opportunityMap[$k]
        $totalOpportunityBytes += $entry.TotalBytes
        $opportunities.Add([PSCustomObject]@{
            OpportunityCategory = $entry.Category
            FileCount           = $entry.FileCount
            PotentialSpaceBytes = $entry.TotalBytes
            PotentialSpaceMB    = [math]::Round($entry.TotalBytes / 1MB, 2)
            PotentialSpaceGB    = [math]::Round($entry.TotalBytes / 1GB, 3)
        })
    }

    return [PSCustomObject]@{
        CategoryA               = $categoryA.ToArray()
        CategoryB               = $categoryB.ToArray()
        CategoryC               = $categoryC.ToArray()
        LargeFiles              = $largeFiles.ToArray()
        OldFiles                = $oldFiles.ToArray()
        CleanupOpportunities   = ($opportunities | Sort-Object -Property PotentialSpaceBytes -Descending)
        TotalPotentialCleanupGB = [math]::Round($totalOpportunityBytes / 1GB, 3)
    }
}

Export-ModuleMember -Function Invoke-FileClassification
