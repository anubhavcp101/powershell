# =========================================================================
# Module: FileDiscovery.psm1
# Windows Server Disk Space Management & Analysis Framework
# Robust, high-performance, non-recursive stack-based scanner.
# Strict safety: ignores reparse points/junctions, handles access-denied.
# =========================================================================

Set-StrictMode -Version 2.0

function Get-DiskFileInventory {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$RootPaths,

        [Parameter(Mandatory = $false)]
        [string[]]$ExcludePaths = @(),

        [Parameter(Mandatory = $false)]
        [int]$MaxDepth = 25,

        [Parameter(Mandatory = $false)]
        [switch]$SkipReparsePoints = $true
    )

    $now = Get-Date
    $discoveredFiles = [System.Collections.Generic.List[PSObject]]::new()
    $dirStack = [System.Collections.Generic.Stack[PSObject]]::new()

    # Pre-normalize exclusions
    $normalizedExclusions = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($ex in $ExcludePaths) {
        if (-not [string]::IsNullOrWhiteSpace($ex)) {
            [void]$normalizedExclusions.Add($ex.TrimEnd('\/'))
        }
    }

    # Initialize roots
    foreach ($path in $RootPaths) {
        if (Test-Path -LiteralPath $path) {
            $dirStack.Push([PSCustomObject]@{
                Path  = (Get-Item -LiteralPath $path).FullName
                Depth = 0
            })
        }
        else {
            Write-DiskLog -Message "Specified root path does not exist, skipping: $path" -Level "DEBUG"
        }
    }

    $processedDirCount = 0

    while ($dirStack.Count -gt 0) {
        $current = $dirStack.Pop()
        $currentPath = $current.Path
        $currentDepth = $current.Depth

        $processedDirCount++
        if ($processedDirCount % 500 -eq 0) {
            Write-Progress -Activity "Discovering Files" -Status "Processed $processedDirCount folders, found $($discoveredFiles.Count) files..." -PercentComplete -1
        }

        # Check exclusion
        if ($normalizedExclusions.Contains($currentPath.TrimEnd('\/'))) {
            Write-DiskLog -Message "Path matched exclusion, skipping: $currentPath" -Level "DEBUG"
            continue
        }

        $dirInfo = $null
        try {
            $dirInfo = [System.IO.DirectoryInfo]::new($currentPath)
        }
        catch {
            Register-DiskScanError -Path $currentPath -ErrorType "DirectoryInitFailure" -ErrorMessage $_.Exception.Message
            continue
        }

        # Check if current directory itself is a reparse point (junction / symlink)
        if ($SkipReparsePoints -and (($dirInfo.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -eq [System.IO.FileAttributes]::ReparsePoint)) {
            Write-DiskLog -Message "Reparse point/Junction detected. Skipping recursion: $currentPath" -Level "DEBUG"
            continue
        }

        # Enumerate Files in current directory
        try {
            $files = $dirInfo.EnumerateFiles()
            foreach ($file in $files) {
                try {
                    $length = $file.Length
                    $lastWrite = $file.LastWriteTime
                    $creation = $file.CreationTime
                    $lastAccess = $file.LastAccessTime
                    $ext = $file.Extension.ToLowerInvariant()
                    $ageDays = [math]::Round(($now - $lastWrite).TotalDays, 1)

                    $discoveredFiles.Add([PSCustomObject]@{
                        FullName       = $file.FullName
                        Name           = $file.Name
                        DirectoryName  = $file.DirectoryName
                        Length         = $length
                        LengthMB       = [math]::Round($length / 1MB, 2)
                        LengthGB       = [math]::Round($length / 1GB, 3)
                        Extension      = $ext
                        CreationTime   = $creation
                        LastWriteTime  = $lastWrite
                        LastAccessTime = $lastAccess
                        AgeDays        = $ageDays
                        Attributes     = $file.Attributes.ToString()
                    })
                }
                catch {
                    # Handle single file lock/read error
                    Register-DiskScanError -Path $file.FullName -ErrorType "FilePropertyReadError" -ErrorMessage $_.Exception.Message
                }
            }
        }
        catch [System.UnauthorizedAccessException] {
            Register-DiskScanError -Path $currentPath -ErrorType "AccessDenied" -ErrorMessage "UnauthorizedAccessException: Access is denied."
        }
        catch [System.IO.PathTooLongException] {
            Register-DiskScanError -Path $currentPath -ErrorType "PathTooLong" -ErrorMessage "Path exceeds Windows maximum length limitation."
        }
        catch {
            Register-DiskScanError -Path $currentPath -ErrorType "FileEnumerationError" -ErrorMessage $_.Exception.Message
        }

        # Enumerate Subdirectories
        if ($currentDepth -lt $MaxDepth) {
            try {
                $subDirs = $dirInfo.EnumerateDirectories()
                foreach ($sub in $subDirs) {
                    try {
                        # Skip reparse points before queueing
                        if ($SkipReparsePoints -and (($sub.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -eq [System.IO.FileAttributes]::ReparsePoint)) {
                            Write-DiskLog -Message "Subdirectory is reparse point. Skipping: $($sub.FullName)" -Level "DEBUG"
                            continue
                        }

                        $subPath = $sub.FullName
                        if (-not $normalizedExclusions.Contains($subPath.TrimEnd('\/'))) {
                            $dirStack.Push([PSCustomObject]@{
                                Path  = $subPath
                                Depth = $currentDepth + 1
                            })
                        }
                    }
                    catch {
                        Register-DiskScanError -Path $sub.FullName -ErrorType "SubDirInspectError" -ErrorMessage $_.Exception.Message
                    }
                }
            }
            catch [System.UnauthorizedAccessException] {
                Register-DiskScanError -Path $currentPath -ErrorType "SubDirAccessDenied" -ErrorMessage "Access denied when enumerating subdirectories."
            }
            catch {
                Register-DiskScanError -Path $currentPath -ErrorType "SubDirEnumerationError" -ErrorMessage $_.Exception.Message
            }
        }
    }

    Write-Progress -Activity "Discovering Files" -Completed
    Write-DiskLog -Message "Discovered $($discoveredFiles.Count) total files across $processedDirCount directories." -Level "SUCCESS"
    return $discoveredFiles.ToArray()
}

Export-ModuleMember -Function Get-DiskFileInventory
