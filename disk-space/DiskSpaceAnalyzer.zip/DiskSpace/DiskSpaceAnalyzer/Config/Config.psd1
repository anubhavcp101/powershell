@{
    # =========================================================================
    # Windows Server Disk Space Management & Analysis Framework - Configuration
    # Safe, Read-Only, Fully Compatible with Windows Server 2016 - 2025 (PS 5.1+)
    # =========================================================================

    # Target drive and root scan settings
    TargetDrives            = @('C:')
    DefaultMode             = 'Full' # Options: Discovery, Audit, Detailed, Report, Full

    # Predefined high-value target scan locations on system drive
    PredefinedScanPaths     = @(
        # Windows system and log directories
        '\Windows\Logs',
        '\Windows\Temp',
        '\Windows\Minidump',
        '\Windows\LiveKernelReports',
        '\Windows\Panther',
        '\Windows\Debug',
        '\Windows\System32\LogFiles',
        '\Windows\Logs\CBS',
        '\Windows\Logs\DISM',
        '\Windows\SoftwareDistribution\Download',
        '\Windows\System32\winevt\Logs',
        '\Windows\Prefetch',
        '\Windows\Installer',
        '\Windows\WinSxS',
        '\Windows\Downloaded Program Files',
        '\Windows\System32\config',
        '\Windows\System32\WMI',

        # Application, user and system directories
        '\ProgramData',
        '\ProgramData\Microsoft\Windows\WER',
        '\inetpub\logs\LogFiles',
        '\Users'
    )

    # Protected or sensitive locations to report size only and mark Protected / Manual Review
    ProtectedLocations      = @(
        '\Windows\System32\config',
        '\Windows\WinSxS',
        '\Windows\Installer',
        '\Windows\System32\winevt\Logs',
        '\System Volume Information',
        '\$Recycle.Bin',
        '\Recovery',
        '\Boot',
        '\EFI'
    )

    # Retention thresholds (in Days) by file category
    AgeThresholds           = @{
        'ETL_Logs'           = 180
        'EVTX_Logs'          = 180
        'General_App_Logs'   = 180
        'IIS_Logs'           = 90
        'Crash_Dumps'        = 90
        'Temporary_Files'    = 14
        'Backup_Files'       = 180
        'Other_Historical'   = 180
        'Default_Old_Files'  = 180
    }

    # Extension categories mapping
    ExtensionCategories     = @{
        'LoggingAndTracing' = @('.etl', '.evtx', '.log', '.trace', '.blg', '.wer', '.log.gz')
        'CrashDumps'        = @('.dmp', '.hdmp', '.mdmp')
        'TemporaryFiles'    = @('.tmp', '.temp', '.old', '.bak', '.backup', '.~tmp', '.swp')
        'InstallerUpdates'  = @('.cab', '.msi', '.msp', '.wim', '.esd')
        'Archives'          = @('.zip', '.7z', '.rar', '.gz', '.tar', '.bz2')
        'DatabaseFiles'     = @('.mdf', '.ldf', '.ndf', '.edb', '.dit')
        'VirtualDisks'      = @('.vhd', '.vhdx', '.vmdk')
    }

    # Thresholds for detection
    Thresholds              = @{
        # Large file minimum size in Megabytes (e.g., 100 MB)
        LargeFileThresholdMB      = 100
        # High directory file count threshold
        HighFileCountThreshold    = 5000
        # Top N count for reporting
        TopLargestFilesCount      = 30
        # Top N directories count for reporting
        TopLargestDirsCount       = 30
    }

    # Special Windows analysis module switches
    SpecialAnalysis         = @{
        AnalyzeComponentStore = $true   # Runs DISM /AnalyzeComponentStore (read-only)
        AnalyzeShadowCopies   = $true   # Queries VSS storage allocation
        AnalyzeUpdateCache    = $true   # Evaluates SoftwareDistribution\Download
        AnalyzeIISLogs        = $true   # Analyzes IIS log directory if inetpub exists
        AnalyzeWER            = $true   # Windows Error Reporting analysis
        AnalyzeCrashDumps     = $true   # Kernel and user dump analysis
        AnalyzePagefiles      = $true   # Pagefile and swapfile discovery
    }

    # Output and Reporting Paths
    Reporting               = @{
        ReportsDirectory      = 'Reports'
        LogsDirectory         = 'Logs'
        GenerateHtmlReport    = $true
        GenerateCsvReports    = $true
        # Maximum files to export to AllDiscoveredFiles.csv to avoid Excel limits / memory strain
        MaxCsvFileExportRows  = 500000
    }
}
