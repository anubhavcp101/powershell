<#
.SYNOPSIS
    Windows Server Disk Space Management & Analysis Framework - Main Orchestrator.
.DESCRIPTION
    Strictly read-only discovery and auditing framework for Windows Server 2016 - 2025.
    Analyzes disk usage, identifies oversized and historical files, evaluates system
    components (DISM WinSxS, VSS, IIS, WER, Pagefile), classifies findings into
    risk-aware categories, and generates Executive HTML and detailed CSV reports.
.PARAMETER Drives
    Target drive letter(s) to scan (e.g. 'C:'). Default is 'C:'.
.PARAMETER ScanPaths
    Optional custom array of directory paths to scan. If omitted, uses Config.psd1.
.PARAMETER ConfigPath
    Path to custom configuration file. Defaults to Config\Config.psd1.
.PARAMETER Mode
    Operational mode: Discovery, Audit, Detailed, Report, or Full (Default).
.PARAMETER OutputPath
    Directory where HTML and CSV reports will be saved. Defaults to Reports\.
.PARAMETER SkipDism
    Skip running DISM Component Store analysis (useful for rapid audits).
.PARAMETER SkipShadowCopy
    Skip querying VSS Volume Shadow Storage.
.EXAMPLE
    .\Start-DiskSpaceAnalysis.ps1 -Mode Full
.EXAMPLE
    .\Start-DiskSpaceAnalysis.ps1 -Drives 'C:' -SkipDism
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string[]]$Drives = @('C:'),

    [Parameter(Mandatory = $false)]
    [string[]]$ScanPaths = $null,

    [Parameter(Mandatory = $false)]
    [string]$ConfigPath = $null,

    [Parameter(Mandatory = $false)]
    [ValidateSet('Discovery', 'Audit', 'Detailed', 'Report', 'Full')]
    [string]$Mode = 'Full',

    [Parameter(Mandatory = $false)]
    [string]$OutputPath = $null,

    [Parameter(Mandatory = $false)]
    [switch]$SkipDism,

    [Parameter(Mandatory = $false)]
    [switch]$SkipShadowCopy
)

Set-StrictMode -Version 2.0
$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

# 1. Resolve Framework Paths & Load Configuration
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($ConfigPath)) {
    $ConfigPath = Join-Path -Path $scriptDir -ChildPath "Config\Config.psd1"
}

if (-not (Test-Path -LiteralPath $ConfigPath)) {
    Write-Error "Configuration file not found: $ConfigPath"
    return
}

$config = Import-PowerShellDataFile -Path $ConfigPath

# 2. Import Framework Modules
$modulesDir = Join-Path -Path $scriptDir -ChildPath "Modules"
$moduleList = @(
    "Logging.psm1",
    "DiskDiscovery.psm1",
    "FileDiscovery.psm1",
    "DirectoryAnalysis.psm1",
    "FileClassification.psm1",
    "WindowsAnalysis.psm1",
    "ReportGenerator.psm1"
)

foreach ($mod in $moduleList) {
    $modPath = Join-Path -Path $modulesDir -ChildPath $mod
    if (Test-Path -LiteralPath $modPath) {
        Import-Module -Name $modPath -Force -DisableNameChecking
    }
    else {
        Write-Error "Required module not found: $modPath"
        return
    }
}

# 3. Initialize Structured Logging
$logsDir = Join-Path -Path $scriptDir -ChildPath $config.Reporting.LogsDirectory
$logFile = Initialize-DiskLogger -LogsDirectory $logsDir

Write-DiskLog -Message "==========================================================================" -Level "INFO"
Write-DiskLog -Message "Starting Windows Server Disk Space Analysis Framework (Mode: $Mode)" -Level "INFO"
Write-DiskLog -Message "CRITICAL SAFETY GUARANTEE: STRICTLY READ-ONLY OPERATION" -Level "SUCCESS"
Write-DiskLog -Message "==========================================================================" -Level "INFO"

# 4. Gather System Information
$osName = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Name "ProductName" -ErrorAction SilentlyContinue).ProductName
if (-not $osName) { $osName = [System.Environment]::OSVersion.ToString() }

$systemInfo = [PSCustomObject]@{
    ComputerName  = $env:COMPUTERNAME
    OSVersion     = $osName
    PSVersion     = $PSVersionTable.PSVersion.ToString()
    ScanTimestamp = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
    ScanDuration  = ""
}

# 5. Phase 1: Disk Overview Discovery
Write-DiskLog -Message "Phase 1: Querying disk and volume metrics..." -Level "INFO"
$targetDrives = if ($PSBoundParameters.ContainsKey('Drives')) { $Drives } else { $config.TargetDrives }
$diskOverview = Get-DiskSpaceOverview -Drives $targetDrives

foreach ($d in $diskOverview) {
    Write-DiskLog -Message "Drive $($d.DriveLetter) | Total: $($d.TotalGB) GB | Used: $($d.UsedGB) GB ($($d.UsedPercent)%) | Free: $($d.FreeGB) GB ($($d.FreePercent)%)" -Level "INFO"
    if ($d.IsCriticalSpace) {
        Write-DiskLog -Message "CRITICAL: Drive $($d.DriveLetter) has less than 10% free space remaining!" -Level "WARN"
    }
}

# 6. Phase 2: File and Directory Discovery
$allDiscoveredFiles = @()
$scanTargetRoots = [System.Collections.Generic.List[string]]::new()

if ($ScanPaths) {
    foreach ($p in $ScanPaths) { [void]$scanTargetRoots.Add($p) }
}
else {
    foreach ($drive in $targetDrives) {
        $cleanDrive = $drive.TrimEnd('\')
        foreach ($prePath in $config.PredefinedScanPaths) {
            $fullPath = "$cleanDrive$prePath"
            [void]$scanTargetRoots.Add($fullPath)
        }
    }
}

Write-DiskLog -Message "Phase 2: Scanning $($scanTargetRoots.Count) configured locations..." -Level "INFO"
$allDiscoveredFiles = Get-DiskFileInventory -RootPaths $scanTargetRoots.ToArray() -ExcludePaths $config.ProtectedLocations

# 7. Phase 3: Directory and Extension Aggregation
Write-DiskLog -Message "Phase 3: Aggregating directory sizes and extension statistics..." -Level "INFO"
$dirSummary = Get-DirectorySizeSummary -FileList $allDiscoveredFiles -TopCount $config.Thresholds.TopLargestDirsCount -HighFileCountThreshold $config.Thresholds.HighFileCountThreshold
$extSummary = Get-ExtensionDistribution -FileList $allDiscoveredFiles

# 8. Phase 4: Classification Engine (Category A, B, C)
Write-DiskLog -Message "Phase 4: Classifying files into Candidate, Manual Investigation, and Protected..." -Level "INFO"
$classification = Invoke-FileClassification -FileList $allDiscoveredFiles -Config $config

Write-DiskLog -Message "Classification Summary:" -Level "SUCCESS"
Write-DiskLog -Message "  - Category A (Potential Cleanup Candidates): $($classification.CategoryA.Count) files (~$($classification.TotalPotentialCleanupGB) GB)" -Level "SUCCESS"
Write-DiskLog -Message "  - Category B (Manual Investigation Required): $($classification.CategoryB.Count) files" -Level "INFO"
Write-DiskLog -Message "  - Category C (Protected Locations/Files): $($classification.CategoryC.Count) files" -Level "INFO"
Write-DiskLog -Message "  - Large Files (>= $($config.Thresholds.LargeFileThresholdMB) MB): $($classification.LargeFiles.Count) files" -Level "INFO"

# 9. Phase 5: Windows Subsystem Special Analysis
$windowsAnalysis = [PSCustomObject]@{
    ComponentStore = $null
    UpdateCache    = $null
    WER            = $null
    IISLogs        = $null
    CrashDumps     = $null
    ShadowCopies   = $null
    Pagefiles      = $null
}

if ($Mode -in @('Detailed', 'Full')) {
    Write-DiskLog -Message "Phase 5: Performing specialized Windows subsystem analysis..." -Level "INFO"

    if ($config.SpecialAnalysis.ContainsKey('AnalyzeComponentStore') -and $config.SpecialAnalysis.AnalyzeComponentStore -and -not $SkipDism) {
        $windowsAnalysis.ComponentStore = Get-WindowsComponentStoreAnalysis
    }

    if ($config.SpecialAnalysis.ContainsKey('AnalyzeShadowCopies') -and $config.SpecialAnalysis.AnalyzeShadowCopies -and -not $SkipShadowCopy) {
        $windowsAnalysis.ShadowCopies = Get-ShadowCopyAnalysis
    }

    if (-not $config.SpecialAnalysis.ContainsKey('AnalyzeUpdateCache') -or $config.SpecialAnalysis.AnalyzeUpdateCache) {
        $windowsAnalysis.UpdateCache = Get-WindowsUpdateCacheAnalysis
    }

    if (-not $config.SpecialAnalysis.ContainsKey('AnalyzeWER') -or $config.SpecialAnalysis.AnalyzeWER) {
        $windowsAnalysis.WER = Get-WindowsWERAnalysis
    }

    if (-not $config.SpecialAnalysis.ContainsKey('AnalyzeIISLogs') -or $config.SpecialAnalysis.AnalyzeIISLogs) {
        $windowsAnalysis.IISLogs = Get-IISLogAnalysis -RetentionDays $config.AgeThresholds.IIS_Logs
    }

    if (-not $config.SpecialAnalysis.ContainsKey('AnalyzeCrashDumps') -or $config.SpecialAnalysis.AnalyzeCrashDumps) {
        $windowsAnalysis.CrashDumps = Get-CrashDumpAnalysis
    }

    if (-not $config.SpecialAnalysis.ContainsKey('AnalyzePagefiles') -or $config.SpecialAnalysis.AnalyzePagefiles) {
        $windowsAnalysis.Pagefiles = Get-PagefileAndSystemFilesAnalysis
    }
}

# 10. Phase 6: Report Generation
$stopwatch.Stop()
$elapsed = $stopwatch.Elapsed
$systemInfo.ScanDuration = "{0:D2}m:{1:D2}s" -f $elapsed.Minutes, $elapsed.Seconds

$scanErrors = Get-DiskScanErrors

$analysisBundle = [PSCustomObject]@{
    SystemInfo       = $systemInfo
    Config           = $config
    DiskOverview     = $diskOverview
    AllFiles         = $allDiscoveredFiles
    DirectorySummary = $dirSummary
    ExtensionSummary = $extSummary
    Classification   = $classification
    WindowsAnalysis  = $windowsAnalysis
    ScanErrors       = $scanErrors
}

$reportResults = $null
if ($Mode -in @('Report', 'Full')) {
    Write-DiskLog -Message "Phase 6: Generating Executive HTML and CSV Reports..." -Level "INFO"
    $repDir = if ($OutputPath) { $OutputPath } else { Join-Path -Path $scriptDir -ChildPath $config.Reporting.ReportsDirectory }
    $reportResults = Export-DiskAnalysisReports -AnalysisData $analysisBundle -OutputDirectory $repDir
}

Write-DiskLog -Message "==========================================================================" -Level "INFO"
Write-DiskLog -Message "Disk Space Analysis completed in $($systemInfo.ScanDuration)." -Level "SUCCESS"
if ($reportResults) {
    Write-DiskLog -Message "HTML Report: $($reportResults.HtmlReport)" -Level "SUCCESS"
}
Write-DiskLog -Message "==========================================================================" -Level "INFO"

return $analysisBundle
